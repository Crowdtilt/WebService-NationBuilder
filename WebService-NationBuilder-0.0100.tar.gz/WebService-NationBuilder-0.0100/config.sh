printf "\nSetting NationBuilder access token...\t\t\t "
export NB_ACCESS_TOKEN=9b88814b8818e9cf45c99fd3e5e35e382f7ef81fd473054444a4f3dde41c8b09
printf "[DONE]\nSetting NationBuilder subdomain...\t\t\t "
export NB_SUBDOMAIN=crowdtilt
printf "[DONE]\n\nReady to run tests!\n\n"
